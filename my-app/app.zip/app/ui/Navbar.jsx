import Link from "next/link";
import styles from "./Navbar.module.css";


export default function Navbar() {
    return (
        <nav className={styles.navbar}>
            <Link className={styles.navitem} href="/home">Home</Link>
            <Link className={styles.navitem} href="/facts">Facts</Link>
            <Link className={styles.navitem} href="/gallery">Gallery</Link>
            <Link className={styles.navitem} href="/about">About</Link>
        </nav>
    )
}